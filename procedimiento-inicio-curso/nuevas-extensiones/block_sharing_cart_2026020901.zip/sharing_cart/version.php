<?php

// @codeCoverageIgnoreStart
defined('MOODLE_INTERNAL') || die();
// @codeCoverageIgnoreEnd

/** @var object $plugin */
$plugin->component = 'block_sharing_cart';
$plugin->version = 2026020901;
$plugin->requires = 2023042400; // Moodle 4.2.0
$plugin->release = '5.1, release 1';
$plugin->maturity = MATURITY_STABLE;
